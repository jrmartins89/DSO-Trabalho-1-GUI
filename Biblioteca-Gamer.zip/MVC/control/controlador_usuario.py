from MVC.model.usuario import Usuario
from MVC.view.tela_usuario import TelaUsuario
from MVC.model.usuarioDAO import UsuarioDAO

class ControladorUsuario:
  def __init__(self, controlador_biblioteca):
      self.__controlador_biblioteca = controlador_biblioteca
      self.__tela = TelaUsuario(self)
      self.__usuarios = UsuarioDAO()
      self.__senha_admin = "ok11blz"

  def abre_tela(self):
    button, values =  self.__tela.open_menu()
    if button == 'Criar usuário':
      self.incluir_usuario(values['nome'],values['email'], values['id_usuario'],values['saldo'],[]) 
    elif button == 'Remover usuário':
      self.excluir_usuario(values['id_usuario'])
    elif button == 'Usuários existentes': 
      self.listar_usuarios()
    elif button == 'Pesquisar por ID':
      self.pesquisar_usuario(values['id_usuario'])
    elif button == 'Adicionar saldo':
      self.adicionar_saldo(values['id_usuario'], float(values['saldo']), values['password'])
    elif button == 'Alterar email':
      self.altera_email(values['id_usuario'],values['email'])
    elif button == 'Voltar ao menu principal':
      self.__controlador_biblioteca.abre_tela()

    
  def verifica_usuario_existente(self):
    pass

  def incluir_usuario(self, nome: str, email: str, id_usuario: str, saldo: float, jogos_adquiridos):
    self.__usuarios.add(Usuario(nome,email,id_usuario,saldo,jogos_adquiridos))
    self.__tela.show_message("Usuários", "Usuário adicionado com sucesso.")

  def excluir_usuario(self, id_usuario: str):
    try:
      for usuario in self.__usuarios.get_all():
       if usuario.id_usuario == id_usuario:
        self.__usuarios.remove(usuario)
        self.__tela.show_message("Usuários", "O usuário foi excluído.") 
    except Exception:
        self.__tela.show_message("Usuários", "Usuário não encontrado")
 
  def listar_usuarios(self):
    lista_usuarios = ''
    for usuario in self.__usuarios.get_all():
      lista_usuarios += "Nome: " + usuario.nome + '\n' + "Email: " + usuario.email + '\n' + "ID Usuário: " + usuario.id_usuario + '\n'
    self.__tela.show_message('Usuários', lista_usuarios)

  def listar_usuario_por_id(self, id_usuario: str):
       for usuario in self.__usuarios.get_all():
        if usuario.id_usuario == id_usuario:
          self.__tela.show_message("Usuarios", usuario.nome + "registro encontrado")
          return usuario


  def pesquisar_usuario(self, id_usuario: str):
    try:
      for usuario in self.__usuarios.get_all():
        if id_usuario == usuario.id_usuario:
          self.__tela.show_message("Usuários",usuario.nome +  "\nID: " + str(usuario.id_usuario)  + "\nSaldo: R$" + str(usuario.saldo))
    except Exception:
      self.__tela.show_message("Erro de Pesquisa", "Usuário não encontrado.")
      

  
  def adicionar_saldo(self, id_usuario: str, saldo: float, senha: str):
    self.__senha_admin = "ok11blz"
    if senha != self.__senha_admin:
      self.__tela.show_message("Erro de senha", "Senha incorreta.") 
    else:
      for usuario in self.__usuarios.get_all(): 
        if usuario.id_usuario == id_usuario:
          usuario.saldo = usuario.saldo + saldo
          self.__tela.show_message("Saldo", "Saldo adicionado com sucesso")
        elif usuario.id_usuario not in self.__usuarios.get_all():
          self.__tela.show_message("Erro de usuario", "Usuário não encontrado. Verifique o ID.")
  
  def altera_email(self, id_usuario: str, email: str):
    for usuario in self.__usuarios.get_all():
        if usuario.id_usuario == id_usuario:
          usuario.email = email
          self.__tela.show_message("Alteração de e-mail", "Email do usuário " + usuario.nome + " alterado.")
        else:
          self.__tela.show_message("Erro de Pesquisa", "Usuário não encontrado. Verifique o ID.")